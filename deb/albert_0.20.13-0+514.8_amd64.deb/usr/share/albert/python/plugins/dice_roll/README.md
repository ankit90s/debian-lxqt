# Dice Roll

Extension for rolling dice

![image](https://user-images.githubusercontent.com/20955511/211666706-eae9c9f2-849f-4b9c-9a59-39d71940b83d.png)

## Usage

Roll any number of dice using the format `_d_`.

Synopsis: `<trigger> <amount>d<sides> [<amount>d<sides> ...]`

Example: `"roll 2d6 3d8 1d20"`
